package com.example.wificam

import android.annotation.SuppressLint
import android.app.Activity
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var connectivityManager: ConnectivityManager
    private var wifiCallback: ConnectivityManager.NetworkCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep the screen on while watching the camera
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        connectivityManager = getSystemService(ConnectivityManager::class.java)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true // lets the page remember the last camera URL
            // The page is loaded from local assets but pulls an http stream from the camera
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/camera_viewer.html")
    }

    override fun onStart() {
        super.onStart()
        bindToWifi()
    }

    override fun onStop() {
        releaseWifi()
        super.onStop()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    /**
     * Force all traffic of this app through the WiFi network.
     * Without this, Android may route traffic over mobile data because the
     * camera's WiFi has no internet, and the camera would be unreachable.
     */
    private fun bindToWifi() {
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                connectivityManager.bindProcessToNetwork(network)
            }

            override fun onLost(network: Network) {
                connectivityManager.bindProcessToNetwork(null)
            }
        }
        wifiCallback = callback
        connectivityManager.requestNetwork(request, callback)
    }

    private fun releaseWifi() {
        wifiCallback?.let {
            try {
                connectivityManager.unregisterNetworkCallback(it)
            } catch (_: Exception) {
                // Callback was already unregistered
            }
        }
        wifiCallback = null
        connectivityManager.bindProcessToNetwork(null)
    }

    // Back button leaves the app (the page has no history to go back to)
}
