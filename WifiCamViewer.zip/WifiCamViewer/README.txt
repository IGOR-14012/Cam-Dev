WiFi Cam Viewer - Android project

Build the APK:
1. Install Android Studio and open this folder (File > Open).
2. Wait for Gradle sync to finish (needs internet the first time).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is at app/build/outputs/apk/debug/app-debug.apk
5. Copy it to the phone and install it (allow "install unknown apps").

Use:
1. Connect the phone to the camera's WiFi (keep it connected even if it says "no internet").
2. Open WiFi Cam Viewer and tap Auto-detect (or type the stream URL and tap Connect).

To change the camera IP or stream paths, edit
app/src/main/assets/camera_viewer.html (CAMERA_IP and CANDIDATES).
